export default function Home() {
  return (
    <div>
      <h1>Welcome to Earnmoney</h1>
      <p>Start earning today!</p>
    </div>
  );
}
